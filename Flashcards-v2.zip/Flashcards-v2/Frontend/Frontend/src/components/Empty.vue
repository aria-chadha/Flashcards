<template>
 <div></div>
</template>


<script lang="ts">
     export default {
       name: 'Empty',
     }       
</script>

<style scoped>

</style>